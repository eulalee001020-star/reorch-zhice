# 数字孪生 PoC 跑通说明

## 目标

本轮数字孪生不是做静态 demo 数据，而是尽量贴近复杂离散制造单车间 PoC：

- 多品种小批量订单。
- 多工序工艺路线。
- 可选设备与设备能力约束。
- 瓶颈设备。
- 物料可用时间。
- 资源日历和停机窗口。
- 产品族换线/设置时间。
- 初始调度多方案。
- 设备异常后的重决策。
- 方案可用性闸门。
- 数字孪生风险评估。
- MES 回写预览。
- PoC ROI 估算。
- 验证证据包：source refs、成本代理、replay/shadow 代理、阈值样本、审计包结构。

## 新增接口

- `POST /api/v1/planning/import/erp-aps`
- `POST /api/v1/planning/initial-schedules`
- `POST /api/v1/planning/digital-twin/sample-run`
- `POST /api/v1/planning/writeback-preview`
- `POST /api/v1/planning/value-report`

## 数字孪生样例

内置样例：`reorch-poc-digital-twin-001`

车间：`WS-HMLV-01`

资源：

- `CNC-01`：铣削/钻孔，瓶颈设备。
- `CNC-02`：铣削/钻孔，存在计划校准停机窗口。
- `LATHE-01`：车削。
- `HT-01`：热处理炉，瓶颈设备，存在温度恢复窗口。
- `ASSY-01`：装配。
- `QC-01`：三坐标检测。
- `PACK-01`：包装。

工单：

- `WO-9001`：Servo housing。
- `WO-9002`：Pump shaft。
- `WO-9003`：Valve block urgent。
- `WO-9004`：Robot joint bracket。
- `WO-9005`：Connector plate。

现实约束：

- 部分工序有替代设备。
- 部分材料延迟到达，例如 `SEAL-KIT`、`BEARING-KIT`。
- `CNC-02` 有刀具校准停机窗口。
- `HT-01` 有温度恢复不可用窗口。
- 不同产品族切换有 20-35 分钟 setup。

## 样例运行结果

最近一次本地运行结果：

- 初始调度生成 5 套方案。
- 选中 `balanced` 作为基准方案。
- 模拟 `CNC-02` 设备告警，预计维修 180 分钟。
- 影响分析识别 5 个受影响工序。
- 策略选择：`wait_and_repair`，置信度 0.75。
- 重排候选：1 个可行方案。
- 方案质量闸门：通过，置信度 `medium`。
- 数字孪生风险分：0.2462。
- 风险标记：`large_schedule_perturbation`。
- Siemens 格式回写预览：5 条指令。
- 单次异常价值估算：7385 元。

## 验证证据包

接口返回 `validation_evidence`，用于在客户现场验证完成前先补齐关键验证证据：

| 字段 | 作用 |
| --- | --- |
| `source_refs` | 绑定 scenario、workshop、baseline snapshot、incident resource、affected work orders、affected operations 和 quality gate plan ids |
| `model_cost_proxy` | 记录外部 LLM 调用数、估算 token、确定性步骤数、候选方案数、回写指令数 |
| `replay_shadow_proxy` | 用数字孪生基线和系统输出对比决策时间、延期、换线、加班和估算价值 |
| `threshold_calibration` | 输出策略置信度、质量门置信度、推荐策略、执行风险分和风险标记 |
| `audit_package_proxy` | 列出输入、基准排程、异常、影响、策略、候选方案、质量门、仿真、回写预览和价值报告 |

## 结果解释

本样例中，系统选择等待修复而不是全局重排，是因为预计维修 180 分钟小于受影响工单总缓冲 990 分钟。该结论并不代表所有设备故障都应等待修复；如果后续接入客户真实订单优先级、物料状态、外协容量、延期罚金和冻结窗口，策略会随现场约束变化。

质量闸门给出 `medium` 而不是 `high`，原因是方案存在较大排程扰动。PoC 阶段这类方案必须由计划员确认，不应自动回写。

## 与真实企业接入的关系

该样例已对齐真实接入所需的数据结构：

- ERP/APS：工单、工序、交期、工艺路线、候选资源。
- MES：当前排程、工序状态、执行进度、回写目标格式。
- IoT：设备异常、告警时间、预计恢复时间。
- 物料系统：材料状态、预计齐套时间。
- 现场规则：设备日历、冻结窗口、产品族换线规则。

后续接真实客户时，不应直接承诺全自动调度，而应先用 `import/erp-aps` 归一化客户数据，再用数据就绪报告决定能否进入排程和异常重决策。
