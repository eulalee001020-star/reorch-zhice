# ReOrch 智策 AI 产品作品集

ReOrch 智策是一个面向复杂离散制造异常重排的受控 AI 决策系统。项目展示了从业务问题识别、AI 能力边界、Agent workflow、求解器与质量门、人工确认、受控回写到案例沉淀的完整链路。

## 项目入口

- `README.md`：项目定位、作品集入口、demo 启动方式。
- `docs/portfolio/portfolio_brief.md`：AI 产品作品集摘要。
- `docs/portfolio/ai_native_pm_capability_map.md`：AI Native 产品经理能力映射。
- `docs/portfolio/industrial_ai_copilot_solution.md`：工业 AI Copilot 方案说明。
- `docs/portfolio/business_process_flow.md`：业务流程图、泳道图和状态机。
- `docs/portfolio/prototype_logic.md`：工作台信息架构、页面逻辑和状态处理。
- `docs/portfolio/metric_system.md`：North Star、分层指标和采集路径。
- `docs/portfolio/project_report_materials.md`：项目汇报结构、答辩问题和材料包索引。
- `docs/portfolio/product_portfolio.md`：项目背景、AI 取舍、产品设计和证据索引。
- `docs/portfolio/workflow_prompts_io.md`：Agent workflow、prompt 模板、输入输出样例。
- `docs/portfolio/trust_quality_gate.md` 与 `docs/validation/failure_case_library.md`：可信性、失败样本和上线边界。

## 本地互动 demo

```bash
cp .env.example .env
docker compose up --build
```

访问 `http://localhost:3000`，账号 `planner / planner123`。

核心路径：登录 -> 决策工作台 -> 加载演示场景 -> 影响分析 -> Top-K 候选方案 -> 推荐解释 -> 人工确认 -> 受控回写 -> 案例库。

## 关键边界

- 本项目证明 MVP、受控试用和 demo 级闭环，不宣称客户生产系统已经正式上线。
- LLM/Agent 负责语义、解释、规则候选和经验沉淀；求解器、质量门、人工确认和审计负责生产责任。
- 默认 demo 不依赖外部 LLM API Key；真实 LLM Agent 是可配置路径。
