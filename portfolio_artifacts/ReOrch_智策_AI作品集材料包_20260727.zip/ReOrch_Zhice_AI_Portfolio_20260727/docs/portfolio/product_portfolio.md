# ReOrch 智策产品作品集

项目：ReOrch 智策  
定位：通用高约束异常决策内核；当前可互动 demo 为制造业异常调度决策 Copilot

## 1. 项目摘要

ReOrch 智策解决的是复杂离散制造中“计划被现场异常打断后，如何快速形成可信、可执行、可追溯的新方案”的问题。系统不把大模型包装成万能排产器，而是用 AI 组织异常理解、规则候选、推荐解释、案例沉淀和偏好学习，再由确定性影响分析、求解器、质量门、数字孪生和计划员确认保证生产责任。

当前进度：MVP 已完成，公开证据来自自动化测试、合成回放和数字孪生演练。现阶段目标是通过 Design Partner 验证流程可用性、数据适配、约束覆盖、计划员接受度和风险提示效果。

为了避免把产品叙事压窄成单一制造场景，ReOrch 在作品集中保留“双层结构”：底层是通用的高约束异常决策内核，上层可以按行业替换领域对象、硬约束、评价指标和解释语言。当前可互动 demo 以离散制造的瓶颈设备异常为主；同时基于 NGS-LRSP 论文和本地 synthetic / digital-twin-style 实验包，重构了一个 NGS 实验室特化版，用来展示同一套内核如何迁移到样本链路、QC、试剂、hold-time、pool/run、index compatibility 和实验室审计更严格的场景。详见 [ngs_lab_specialized_portfolio.md](ngs_lab_specialized_portfolio.md)。

材料索引：

| 材料 | 内容 |
| --- | --- |
| 仓库首页 | 本仓库首页 README |
| 可互动 demo | `docker compose up --build` 后访问 `http://localhost:3000`；制造异常看“决策工作台”，NGS 场景看“NGS Lab” |
| AI Native 能力映射 | [ai_native_pm_capability_map.md](ai_native_pm_capability_map.md) |
| 工作流说明 | [workflow_prompts_io.md](workflow_prompts_io.md) |
| AI 增量 Agent 设计 | [ai_increment_agent_design.md](ai_increment_agent_design.md) |
| NGS 实验室特化版 | [ngs_lab_specialized_portfolio.md](ngs_lab_specialized_portfolio.md)，系统入口为 `POST /api/v1/ngs-lab/demo-run` 和前端 `NGS Lab` 页 |
| Prompt 说明 | [workflow_prompts_io.md](workflow_prompts_io.md) 第 3 节 |
| 输入输出效果示意 | [workflow_prompts_io.md](workflow_prompts_io.md) 第 4 节 |
| 项目能力证据 | [project_capability_evidence.md](project_capability_evidence.md) |
| 市场需求说明 | [market_benchmark.md](market_benchmark.md) |
| 采纳/驳回样本 | [../validation/lab_replay_acceptance_evidence.md](../validation/lab_replay_acceptance_evidence.md) |
| 失败样本库 | [../validation/failure_case_library.md](../validation/failure_case_library.md) |
| LLM Agent 离线评测 | [../validation/llm_agent_offline_eval.md](../validation/llm_agent_offline_eval.md) |
| Data Readiness 停损规则 | [../integration/data_readiness_stop_rules.md](../integration/data_readiness_stop_rules.md) |
| 验收与验证证据 | `pytest -q`、`frontend build`、`docs/demo/demo_validation_report.md`、`docs/validation/digital_twin_validation_pack.md` |

## 2. 为什么选择这个场景

复杂制造企业常见现状不是“没有系统”，而是 ERP/MES/APS/Excel/微信群/电话共同存在。ERP/MES 擅长记录和执行，APS 擅长基准排程，但现场异常发生后的跨角色决策闭环往往仍依赖少数计划员经验。

高频异常包括：

- 设备故障或维修超时。
- 插单、急单和交期变化。
- 物料延期或齐套风险。
- 质量返工。
- 瓶颈资源冲突。
- 换线、夹具、刀具、人员技能等现场隐性约束。

项目的关键判断是把产品切口收窄到“异常响应层”，而不是直接挑战成熟 APS 的全厂级计划能力。首期场景进一步收敛为“关键瓶颈设备故障或停机导致急单延期风险时的局部重排决策”。这符合 B 端产品从受控演练、单车间验证、单异常高频痛点逐步推进的落地规律，也避免把设备故障、插单、物料延期和质量返工包装成一个未经验证的商业切口。

### 2.1 用户与场景拆解

| 维度 | 内容 |
| --- | --- |
| 核心用户 | 计划员、生产主管、车间调度、IT/系统集成负责人 |
| 使用频率 | 设备故障、维修超时、插单、物料延迟等异常发生时触发 |
| 输入信息 | 异常事件、排程快照、工单、工序、设备、日历、物料、预计恢复时间 |
| 期望输出 | 影响范围、候选方案、交付/扰动/换线/风险指标、推荐理由、回写预览 |
| 决策点 | 是否等待维修、局部修复、滚动窗口重排或全局重排 |
| 风险点 | 硬约束不可行、延期误判、过度扰动、越权回写、解释不可追溯 |
| 成功标准 | 异常到方案时间下降、确认前硬约束可行率 100%、计划员采纳率提升、审计可追溯 |

### 2.2 为什么使用 AI

| 替代方案 | 局限 | ReOrch 的取舍 |
| --- | --- | --- |
| 纯规则系统 | 适合固定规则，但难以覆盖现场异常表达、隐性偏好和复杂取舍解释 | 用规则和求解器保证可行性，用 AI 处理语义理解、解释和经验沉淀 |
| 传统 APS 重排 | 强在基准排程和优化，但异常协同、解释、人工 override 沉淀通常较弱 | 不替代 APS，而是在其上做异常响应层 |
| Excel/人工试排 | 灵活但慢、不可追溯，依赖少数计划员经验 | 将异常决策流程产品化，保留人工确认 |
| 自由聊天式 Agent | 输出不可控，难以承担生产责任 | 采用受控 Workflow，所有高风险动作经过质量门和人工确认 |

AI 的增量价值不是“自动排产”，而是把模糊异常输入转成结构化决策上下文，把多目标取舍解释给计划员，并把人工选择和 override 原因沉淀成可复用案例资产。具体拆分为异常理解、规则候选、推荐解释、案例沉淀和偏好学习五个 Agent，见 [ai_increment_agent_design.md](ai_increment_agent_design.md)。

## 3. 产品能力矩阵

| 能力 | 项目体现 | 证据 |
| --- | --- | --- |
| AI 应用产品定义 | 把大模型能力放入可控工作流，明确 Agent、Workflow、求解器和人工确认边界 | `docs/product/poc_system_blueprint.md` |
| 真实业务洞察 | 选择复杂离散制造异常重排作为首批场景，并收敛到单车间、单异常 MVP 验证 | `docs/business/reorch_business_plan.md` |
| 产品规划能力 | Lab Trial -> Pilot -> Convert -> Expand，先完成实验室验证，再推进客户试点 | `docs/business/reorch_business_plan.md` |
| 数据与指标意识 | 异常到方案时间、硬约束可行率、数字孪生 replay/shadow 代理、延期减少、扰动降低、ROI | `frontend/src/pages/PocDashboardPage.tsx` |
| Agent/Workflow 设计 | Incident Intake、Impact、Strategy、Solver、Explanation、Case Memory、Audit 分工，并明确五个 AI 增量 Agent 的产品边界 | [workflow_prompts_io.md](workflow_prompts_io.md)、[ai_increment_agent_design.md](ai_increment_agent_design.md) |
| 工程落地意识 | FastAPI + React + Docker Compose + CI + mock integration + sandbox demo | 根目录 README 与 `.github/workflows/ci.yml` |
| 安全治理意识 | schema 校验、硬约束质量门、置信度降级、人工确认、幂等、审计 | [trust_quality_gate.md](trust_quality_gate.md) |
| 商业判断 | 不夸大“AI 自动排产”，先用数字孪生和受控演练验证方法，再推进客户现场试点 | [market_benchmark.md](market_benchmark.md) |

## 4. 产品设计原则

### 4.1 AI 做什么

- 把自然语言异常、MES 告警、维修估计转成结构化 Incident。
- 根据排程快照识别受影响工序、工单、资源和交付风险。
- 生成策略候选：等待维修、局部修复、滚动窗口重排、全局重排。
- 将自然语言规则转成待审核 constraint candidate。
- 解释 Top-K 候选方案的交付、扰动、换线和执行风险。
- 把计划员选择、override 原因和执行反馈沉淀为案例资产，并在样本足够后形成偏好画像。

### 4.2 AI 不做什么

- 不直接生成最终生产计划。
- 不绕过硬约束校验。
- 不绕过计划员确认直接写回 MES/APS。
- 不把未验证案例直接升级为硬规则。
- 不把 sandbox、受控实验室演练或 synthetic benchmark 宣称为客户生产系统正式上线。

在工业场景，可信 AI 产品的关键不是“让模型更自主”，而是让模型在正确的责任边界内提高协同效率和解释效率。

### 4.3 可信性质量门

ReOrch 不依赖 LLM 自我判断结果是否正确，而是设置外部质量门：

| 判断项 | 标准 |
| --- | --- |
| 结构合法 | schema、枚举、时间、ID、必填字段通过校验 |
| 数据可追溯 | 影响结论能回到 Incident、ScheduleSnapshot、工序、设备和工单 |
| 硬约束 | 推荐前 100% 通过设备能力、工序顺序、资源互斥等核心校验 |
| 业务风险 | 明确暴露延期、扰动、换线、solver 降级和执行复杂度 |
| 置信度 | 低置信度不自动预选，必须提示人工确认 |
| 审计 | 推荐、确认、覆盖、回写和执行反馈均留痕 |

详细实现状态见 [trust_quality_gate.md](trust_quality_gate.md)。

### 4.4 模型分层与成本控制

ReOrch 的成本控制原则是：能用规则、数据库和求解器稳定完成的任务，不交给 LLM；必须使用 LLM 的任务，也按风险和复杂度分层。

| 模块 | 模型策略 | 成本控制 |
| --- | --- | --- |
| 异常分类、字段抽取 | 可配置真实 LLM Agent / 小模型 / 规则分类器，低置信度进入人工确认 | 只传异常文本和必要上下文，不传完整排程表 |
| 规则候选结构化 | 可配置真实 LLM Agent + schema 输出 | 结构化输出减少重试，候选规则不直接生效 |
| 计划员反馈结构化 | 可配置真实 LLM Agent + 确定性降级 | 只沉淀 override 原因和候选规则，不改求解器 |
| 方案解释 | 中等模型可润色，但必须基于结构化 KPI、质量门和 source refs | 常见解释模板化，复杂冲突场景再升级模型 |
| 影响分析、候选方案生成、质量门 | 不使用 LLM | 由确定性服务、OR-Tools、ConstraintValidator 和 PlanQualityGate 完成 |
| 案例沉淀 | 小模型辅助提取 override 原因和经验标签 | 人工审核后进入案例资产 |

当前默认 demo 仍关闭外部 LLM，便于使用者在无 API Key 的情况下复现；但异常理解、规则候选和计划员反馈结构化已经接入可配置真实 LLM Agent 路径。配置 `LLM_ENABLED=true`、`LLM_API_KEY`、`LLM_BASE_URL` 和 `LLM_MODEL` 后，Agent trace 会记录模型、token、latency 和降级原因。高风险的影响分析、候选方案生成、质量门、推荐确认和回写仍不交给 LLM。

### 4.5 结果可用标准

LLM 结果不能因为表达自信就直接进入生产决策。ReOrch 将结果分为三类处理：

| 输出类型 | 是否可直接使用 | 处理标准 |
| --- | --- | --- |
| 解释草稿、风险提示、规则候选 | 可作为辅助信息 | 必须绑定 source refs，并标注置信度或审核状态 |
| 候选排程方案 | 不能直接使用 | 必须通过求解器、硬约束、质量门、数字孪生风险评估 |
| 生产回写指令 | 不能自动执行 | 必须经过计划员确认、权限校验、回写预览和审计记录 |

因此，ReOrch 判断结果是否可用，不是看 LLM 说得是否合理，而是看它是否通过外部验证链路：schema、数据追溯、硬约束、风险阈值、置信度、人工确认和审计。

## 5. Demo 操作流程

1. 登录 `planner / planner123`。
2. 打开“决策工作台”。
3. 点击“加载演示场景”。
4. 说明场景：`M-03` CNC 单元突发故障，预计停机 4 小时，急单存在延期风险。
5. 展示影响分析：受影响工序、工单、资源、交期风险。
6. 展示候选方案：等待维修、局部修复、滚动窗口重排、全局重排。
7. 展示多目标评价：延期、扰动、换线、资源切换、可行性、置信度。
8. 展示推荐解释：为什么推荐方案在交付和执行稳定性之间更均衡。
9. 点击确认采纳，展示 mock MES/APS 受控回写。
10. 打开案例库，展示决策记录和经验沉淀。

## 6. 可快速验证的证据

| 证据 | 当前状态 |
| --- | --- |
| 后端测试 | `pytest -q`: 717 passed |
| 前端构建 | `npm run build` 通过 |
| Demo 数据校验 | 69 条记录，0 blocking error |
| Sandbox 数据 | 12 个工单、48 道工序、8 台设备、1 个核心异常 |
| 数字孪生验证 | 5 套初始方案、5 个受影响工序、1 个可行重排方案、风险分 0.2462、单次价值估算 7385 元 |
| 实验室验证 | 已具备受控演练条件，尚无 Design Partner 验证证据 |
| 安全边界 | 人工确认前不回写，生产接入从只读和 shadow mode 开始 |
| 上线判断 | 当前支持受控试用和验证，不建议直接生产上线 |

## 6.1 评测与迭代

| 层级 | 指标 | 当前证据 |
| --- | --- | --- |
| 模型/结构层 | schema 通过率、结构化输出稳定性、source refs 覆盖 | Pydantic、TypeScript types、`validation_evidence.source_refs` |
| 方案层 | 硬约束可行率、质量门结果、执行风险分 | `PlanQualityGate`、数字孪生风险分 0.2462 |
| 产品层 | 异常到方案时间、人工确认率、低置信人工介入率 | 数字孪生代理：90 分钟人工基线 vs 8 分钟系统决策 |
| 业务层 | 延期减少、换线减少、加班减少、估算价值 | 数字孪生代理：延期减少 150 分钟、换线减少 3 次、估算价值 7385 元 |
| 风险层 | 越权回写、硬约束失败、审计缺失、回滚缺失 | 人工确认、mock writeback、`audit_package_proxy` |

当前暴露的典型失败/边界样本：

| 样本 | 现象 | 处理 |
| --- | --- | --- |
| 数字孪生重排扰动较大 | `large_schedule_perturbation`，质量门置信度为 `medium` | 不自动写回，要求计划员确认 |
| 约束覆盖有限 | 质量门 warning：constraint coverage limited | 在 Design Partner 场景验证物料、人员、工装夹具等现场约束 |
| 生产上线边界 | MVP 可受控试用，但不适合无人值守自动调度 | 上线就绪评估要求只读接入、shadow mode、回滚和审计验收 |

## 7. 三分钟项目介绍

可以这样介绍：

```text
ReOrch 智策不是一个“AI 排产聊天机器人”，而是工业异常调度的受控决策 Copilot。
复杂制造企业真正痛的是计划执行中持续被设备故障、插单、物料和返工打断，
计划员要在交付、扰动、换线、瓶颈和加班之间做权衡。

ReOrch 的产品方案是把异常发生后的流程产品化：
先锁定排程快照，再做影响分析，再生成多策略候选方案，
再通过硬约束质量门和多目标指标评估，最后由计划员确认后受控回写。
AI 负责异常理解、规则候选、推荐解释、案例沉淀和偏好学习，不直接越权改生产计划。

项目里有可运行前端 demo、后端 API、Docker Compose、测试、MVP 数据模板、
prompt 工作流和实验室验证路径，展示从问题定义到受控验证的完整闭环。
```

## 8. 后续迭代路线

| 阶段 | 目标 | 成功标准 |
| --- | --- | --- |
| P0 | MVP 完成与受控实验室演练 | 10-30 分钟内生成可解释候选方案，完成演练证据 |
| P1 | 数字孪生 replay/shadow 代理 + Design Partner 复核 | Top-N 覆盖、低风险场景采纳率和计划员反馈可量化 |
| P2 | 客户现场受控试点 | 只读接入、人工确认 dry-run、审计包和回滚预案齐备 |
| P3 | 生产小范围上线 | 全链路审计、幂等、防重复提交、失败回滚和运维验收齐备 |

## 9. 参考对标

- 阿里云 Model Studio 将应用分为 Agent、Workflow 和高代码应用，并指出需要固定、可重复、明确输入输出时应使用 Workflow 思路：[阿里云百炼应用类型介绍](https://help.aliyun.com/zh/model-studio/application-introduction)。
- 阿里云英文文档同样强调 Workflow 更适合 deterministic control 和 auditable steps：[Model Studio application overview](https://www.alibabacloud.com/help/en/model-studio/application-introduction)。
- 工信部等六部门 2025 年智能工厂梯度培育行动明确把基础级、先进级、卓越级、领航级作为智能工厂升级路径，并要求卓越级/领航级探索或深度应用人工智能技术：[工信部通知](https://www.miit.gov.cn/zwgk/zcwj/wjfb/tz/art/2025/art_57f2e7f7bdfd4bf1bd52e4fbdcd6d69e.html)。
