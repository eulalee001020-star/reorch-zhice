# ReOrch 智策 - AI 产品作品集材料包

ReOrch 是位于 ERP / MES / APS 之上的工业异常恢复决策 Copilot。材料包包含
PDF / DOCX 项目说明、PRD、业务流程、原型逻辑、指标、评测、失败迭代、
核心工程代码、测试、验证报告与独立互动 Demo 源码。

## 入口

- `ReOrch_Zhice_AI_Product_Portfolio_20260727.pdf`
- `ReOrch_Zhice_AI_Product_Portfolio_20260727.docx`
- `README.md`
- `docs/product/prd_decision_workbench.md`
- `docs/portfolio/business_process_flow.md`
- `docs/portfolio/prototype_logic.md`
- `docs/portfolio/metric_system.md`
- `docs/portfolio/evaluation_guardrail_cases.md`
- `docs/portfolio/failure_iteration_log.md`
- `docs/validation/production_runtime_completion_report_20260712.md`
- `portfolio_site/`

## 证据边界

- 当前公开证据来自自动化测试、公开来源数据、合成回放与数字孪生演练。
- 真实 Design Partner 案例数为 0，尚无客户生产数据或财务确认 ROI。
- 生产写回默认关闭，LLM 不负责硬约束、排程可行性或最终执行责任。
